@extends('culture/culture_list/template/app')

@section('content')
  <section class="cultureListSianture">
    <img src="../front/image/imgCultureList4.png" class="img-fluid" alt="imageIntro4">
    <div class="container">
      <div class="row ">
        <div class="judulCulture col-12">
          <h1 class="display-3 fw-bold text-center">{{$kategori->nama}}</h1>
        </div>
        <div id="carouselExampleControls" class="carousel slide " data-bs-ride="carousel">
          <div class="carousel-inner ">
            <div class="carousel-item active ">
              @foreach ($artikel as $row)
                  <div class="row ">
                    <div class="col text-center p-3">
                      <img class="img-fluid w-25" src="/upload/post/{{$row->sampul}}" alt="{{$row->judul}}">
                      <button class="m-4 btn btn-primary w-50" type="button"><a href="/culture/{{$kategori->slug}}/{{$row->slug}}">{{$row->judul}}</a></button>
                    </div>
                  </div>    
              @endforeach
            </div>
          </div>
          {{-- <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button> --}}
        </div>
      </div>
      <a href="/culture" style="padding-bottom: 70px">
        <img src="../front/image/previous.png" alt="">
      <a>
  </section>
@endsection