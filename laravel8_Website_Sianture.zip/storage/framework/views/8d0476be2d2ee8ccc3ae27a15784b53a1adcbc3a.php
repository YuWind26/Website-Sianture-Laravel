

<?php $__env->startSection('title','Sianture-Show'); ?>

<?php $__env->startSection('post','active'); ?>

<?php $__env->startSection('main','show'); ?>

<?php $__env->startSection('main-active','active'); ?>

<?php $__env->startSection('content'); ?>
    <a href="/post/<?php echo e($post->id); ?>/edit" class="btn btn-primary fas fa-edit btn-sm">Edit</a>
    <a href="/post" class="btn btn-secondary  fas fa-arrow-left btn-sm">Kembali</a>
    <div class="card mt-3"> 
        <img src="/upload/post/<?php echo e($post->sampul); ?>"  height="450px" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($post->judul); ?></h5>
            <p class="card-text"><?php echo $post->konten; ?></p>
            <p class="card-text"><small class="text-muted"><?php echo e($post->created_at->diffforhumans()); ?></small></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sb-admin/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/post/show.blade.php ENDPATH**/ ?>