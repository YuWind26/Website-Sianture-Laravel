<ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="/dashboard">

    <div class="sidebar-brand-text mx-3">SIANTURE</div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item <?php echo $__env->yieldContent('dashboard'); ?>">
    <a class="nav-link" href="/dashboard">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>

<li class="nav-item <?php echo $__env->yieldContent('post'); ?>">
    <a class="nav-link" href="/post">
        <i class="fas fa-fw fa-file"></i>
        <span>Postingan</span></a>
</li>

<li class="nav-item <?php echo $__env->yieldContent('kategori'); ?>">
    <a class="nav-link" href="/kategori">
        <i class="fas fa-fw fa-tag"></i>
        <span>Kategori</span></a>
</li>



<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item">
    
    <div id="main" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            
            
        </div>
    </div>
</li>

<!-- Nav Item - Utilities Collapse Menu -->


<!-- Divider -->
<hr class="sidebar-divider">

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="/">
        <i class="fas fa-arrow-left"></i>
        <span>Halaman Depan</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/sb-admin/sidebar.blade.php ENDPATH**/ ?>