

<?php $__env->startSection('title','Sianture-Tag'); ?>

<?php $__env->startSection('content'); ?>
    <!-- flashdata -->
    <?php echo session('sukses'); ?>


     <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Tag</h1>

    <a href="/tag/create" class="btn btn-primary btn-sm "><i class="fas fa-plus mx-1"></i>Tambah Tag</a>

    <?php if($tag[0]): ?>
                <!-- Table -->
        <table class="table table-hover mt-4 table-bordered">
            <thead>
                <tr class="table-primary">
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Slug</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tag; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($row->nama); ?></td>
                    <td><?php echo e($row->slug); ?></td>
                    <td align="center" width="20%">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a href="/tag/<?php echo e($row->id); ?>/edit" class="btn btn-primary btn-sm mr-1"><i class="fas fa-edit mx-1"></i>Update</a>
                            <form action="/tag/<?php echo e($row->id); ?>" method="post">
                                <?php echo method_field('DELETE'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Anda Yakin Akan Menghapus Data?')"><i class="fas fa-trash mx-1"></i>Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>



        <?php echo e($tag -> links()); ?>

    <?php else: ?>
        <div class="alert alert-info mt-3" role="alert">
            Anda Belum Mempunyai Data
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sb-admin/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/tag/index.blade.php ENDPATH**/ ?>