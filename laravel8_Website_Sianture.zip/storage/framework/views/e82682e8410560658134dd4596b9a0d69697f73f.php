

<?php $__env->startSection('title','Sianture-Post Content'); ?>

<?php $__env->startSection('content'); ?>
     <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Post</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sb-admin/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/post.blade.php ENDPATH**/ ?>