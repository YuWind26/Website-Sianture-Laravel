

<?php $__env->startSection('content'); ?>

<!--Bagian Teks Di Web  -->
<div class="container-fluid banner2">
  <div class="sianture_2">
      <h3 class="display-6">SIAN<br/>TURE</h3>
  </div>
  <div class="indone_2">Indone</h1>
  </div>
  <div class="cul_2">Cul</h1>
  </div>
    <form>
      <input class="search" type="text" id ="pencarian2" placeholder="Search.." required>	
    </form>
</div>         
<!-- bagian Pelengkap Background -->
<div class="container-fluid tembok"></div>
<div class="container-fluid tembok2"></div>
<div class="container-fluid bawah"></div>
<div class="container-fluid multiple"></div>
<div class="container-fluid image"></div>          
<div class="previous">
  <a href="sianture2_1.html"><img src="previous.png" alt=""></a>
</div>
<!-- Image Detail Rumah Adat -->
<div class="image_rumah_detail">
  <img style="width: 200px;height:200px;" src="image-processing_1.png" alt="">
</div>

<div class="container-fluid bg"></div>
<div class="bg_nama_rumah"></div>
<div class="teks_nama_rumah">Rumah Adat Joglo</div>
<div class="teks_nama_asal">Asal : Jawa Tengah</div>

<div class="teks_detail_rumah">Nama Joglo diambil dari dua suku kata yaitu “Tajug” dan “Loro”. <br>
  <br>Artinya adalah penggabungan dua tajug. Hal ini didasarkan pada atap rumah Joglo yang berbentuk tajug yang serupa dengan gunung.<br>
  
  <br>Orang Jawa kuno percaya bahwa gunung merupakan simbol yang sakral dan merupakan tempat tinggal bagi para dewa. Oleh karena itu, dua tajug dipilih menjadi atap rumah adat Jawa Tengah. Penyangga dari atap rumah adalah empat pilar yang disebut dengan “Saka guru”. Pilar ini adalah representasi arah mata angin yaitu timur, selatan, utara, dan juga barat.<br>
  
  <br>Rumah tradisional Jawa terbagi menjadi dua bagian, yakni rumah induk dan rumah tambahan.<br>
  <br>Rumah induk terdiri dari beberapa bagian sebagai yaitu :<br>
  <br>1.Pendapa/Pendopo<br>
  <br> Pringgitan<br>
  <br>Emperan<br>
  <br>Omah dalem<br>
  <br>Senthong-kiwa<br>
  <br>Senthong tengah<br>
  <br>Senthong-tengen<br>
  <br>Gandhok<br></div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('culture/template/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/culture_detail/culture_detail.blade.php ENDPATH**/ ?>