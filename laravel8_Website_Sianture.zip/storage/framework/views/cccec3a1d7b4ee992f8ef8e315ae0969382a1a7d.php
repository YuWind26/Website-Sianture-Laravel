<!doctype html>
<html lang="en">

  <?php echo $__env->make('/culture/culture_list/template/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    
    <?php echo $__env->make('/culture/culture_list/template/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->make('/culture/culture_list/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('/culture/culture_list/template/javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
  <?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/culture/culture_list/template/app.blade.php ENDPATH**/ ?>