

<?php $__env->startSection('title','Sianture-Kategori'); ?>

<?php $__env->startSection('kategori','active'); ?>

<?php $__env->startSection('main','show'); ?>

<?php $__env->startSection('main-active','active'); ?>

<?php $__env->startSection('content'); ?>
    <!-- flashdata -->
    <?php echo session('sukses'); ?>


     <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Kategori</h1>

    <a href="/kategori/create" class="btn btn-success btn-sm "><i class="fas fa-plus mx-1"></i>Tambah Kategori</a>

    <!-- Table -->
    <table class="table table-hover mt-4 table-bordered">
        <thead>
            <tr class="table-success">
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Slug</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($row->nama); ?></td>
                <td><?php echo e($row->slug); ?></td>
                <td align="center" width="20%">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <a href="/kategori/<?php echo e($row->id); ?>/edit" class="btn btn-success btn-sm mr-1"><i class="fas fa-edit mx-1"></i>Update</a>
                        <a href="/kategori/<?php echo e($row->id); ?>/konfirmasi" class="btn btn-danger btn-sm mr-1"><i class="fas fa-trash mx-1"></i>Delete</a>
                        
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



    <?php echo e($kategori -> links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sb-admin/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>