<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; SIANTURE 2022</span>
                    </div>
                </div>
</footer><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/post/sb-admin/footer.blade.php ENDPATH**/ ?>