<footer class="footer  py-3 mt-5 bg-dark rounded-3">
</footer><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views//profil/template/footer.blade.php ENDPATH**/ ?>