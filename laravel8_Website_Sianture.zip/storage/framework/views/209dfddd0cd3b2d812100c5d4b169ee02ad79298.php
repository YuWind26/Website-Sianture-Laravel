<!doctype html>
<html lang="en">

  <?php echo $__env->make('/home/template/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <body>

    
    <?php echo $__env->make('/home/template/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <?php echo $__env->yieldContent('content'); ?>

    
    <?php echo $__env->make('/home/template/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('/home/template/javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html>
  <?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/home/template/app.blade.php ENDPATH**/ ?>