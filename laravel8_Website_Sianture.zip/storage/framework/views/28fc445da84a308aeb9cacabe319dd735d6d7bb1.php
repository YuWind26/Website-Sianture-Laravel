

<?php $__env->startSection('title','Sianture-Post'); ?>

<?php $__env->startSection('post','active'); ?>

<?php $__env->startSection('main','show'); ?>

<?php $__env->startSection('main-active','active'); ?>

<?php $__env->startSection('content'); ?>
    <!-- flashdata -->
    <?php echo session('sukses'); ?>


     <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Postingan</h1>

    <a href="/post/create" class="btn btn-success btn-sm "><i class="fas fa-plus mx-1"></i>Tambah Postingan</a>

    <?php if($post[0]): ?>
        <!-- Table -->
        <table class="table table-hover mt-4 table-bordered">
            <thead>
                <tr class="table-success">
                    <th scope="col">No</th>
                    <th scope="col">Sampul</th>
                    <th scope="col">Judul</th>
                    <th scope="col">Kategori</th>
                    
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><img src="/upload/post/<?php echo e($row->sampul); ?>" alt="" width="80px" height="80px"></td>
                    <td><?php echo e($row->judul); ?></td>
                    <td><?php echo e($row->kategori->nama); ?></td>
                    
                    <td align="center" width="30%">
                        <div class="btn-group" role="group" aria-label="Basic example">
                            <a href="/post/<?php echo e($row->id); ?>" class="btn btn-dark btn-sm mr-1"><i class="fas fa-eye mx-1"></i>Detail</a>
                            <a href="/post/<?php echo e($row->id); ?>/edit" class="btn btn-success btn-sm mr-1"><i class="fas fa-edit mx-1"></i>Edit</a>
                            <a href="/post/<?php echo e($row->id); ?>/konfirmasi" class="btn btn-danger btn-sm mr-1"><i class="fas fa-trash mx-1"></i>Delete</a>
                            
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($post -> links()); ?>


    <?php else: ?>

        <div class="alert alert-info mt-3" role="alert">
            Anda Belum mempunyai Data
        </div>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sb-admin/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/post/index.blade.php ENDPATH**/ ?>