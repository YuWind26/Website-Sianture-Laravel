

<?php $__env->startSection('content'); ?>
<section class="cultureListSianture">
  <img src="../../front/image/imgCultureList4.png"  alt="imageIntro4">
  <div class="container">

    <div class="row justify-content-center mt-4">
      <div class="col text-center">
        <img  src="../../upload/post/<?php echo e($artikel->sampul); ?>" class="img-responsive w-50" alt="">
      </div>
    </div>
    <div class="row ">
      <div class="col my-3">
        <div class="w-50 text-light bg-dark p-3 mx-auto text-center rounded-3">
          <h2><?php echo e($artikel->judul); ?></h2>
        </div>
      </div>
    </div>
    <div class="row mb-5">
      <div class="col">
        <div class="text-light bg-dark p-3 rounded-3">
          <p><?php echo $artikel->konten; ?></p>
        </div>
      </div>
    </div>

      <a href="/culture/<?php echo e($kategori->slug); ?>">
        <img src="../../front/image/previous.png" alt="">
      <a>
   



</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('culture/culture_list/culture_detail/template/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/culture/culture_list/culture_detail/culture_detail.blade.php ENDPATH**/ ?>