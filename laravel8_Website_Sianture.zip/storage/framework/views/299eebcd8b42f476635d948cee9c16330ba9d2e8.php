<a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
</a><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/admin/post/sb-admin/button-topbar.blade.php ENDPATH**/ ?>