

<?php $__env->startSection('content'); ?>
  <section class="cultureListSianture">
    <img src="../front/image/imgCultureList4.png" class="img-fluid" alt="imageIntro4">
    <div class="container">
      <div class="row ">
        <div class="judulCulture col-12">
          <h1 class="display-3 fw-bold text-center"><?php echo e($kategori->nama); ?></h1>
        </div>
        <div id="carouselExampleControls" class="carousel slide " data-bs-ride="carousel">
          <div class="carousel-inner ">
            <div class="carousel-item active ">
              <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row ">
                    <div class="col text-center p-3">
                      <img class="img-fluid w-25" src="/upload/post/<?php echo e($row->sampul); ?>" alt="<?php echo e($row->judul); ?>">
                      <button class="m-4 btn btn-primary w-50" type="button"><a href="/culture/<?php echo e($kategori->slug); ?>/<?php echo e($row->slug); ?>"><?php echo e($row->judul); ?></a></button>
                    </div>
                  </div>    
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
          
        </div>
      </div>
      <a href="/culture" style="padding-bottom: 70px">
        <img src="../front/image/previous.png" alt="">
      <a>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('culture/culture_list/template/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/culture/culture_list/culture_list.blade.php ENDPATH**/ ?>