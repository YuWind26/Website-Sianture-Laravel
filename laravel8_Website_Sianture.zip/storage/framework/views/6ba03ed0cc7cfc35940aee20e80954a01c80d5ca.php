

<?php $__env->startSection('content'); ?>

<body>
    <section class="cultureSianture pb-3">
        <img class="img-fluid" src="front/image/imgCulture2.png" alt="imageIntro4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="judulCulture col-12 justify-content-center">
              <h1 class="display-3 fw-bold text-center">Budaya Indonesia</h1>
            </div>
          </div>
          <div class="row justify-content-center pb-5  text-center">
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-3 my-2">
                <div class="bg-success p-3 rounded-3 mt-2">
                  <a href="/culture/<?php echo e($row->slug); ?>" style="text-decoration: none;color:white"><h2><?php echo e($row->nama); ?></h2></a>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>
        </div>
      </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('culture/template/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\My Project\Project Website\laravel8_Website_Sianture\resources\views/culture/culture.blade.php ENDPATH**/ ?>